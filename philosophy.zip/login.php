 <?php
 require_once ("include/initialize.php"); 
 if(isset($_POST['submit'])){
  $email = trim($_POST['U_USERNAME']);
  $upass  = trim($_POST['U_PASS']);
  $h_upass = sha1($upass);
  
   if ($email == '' OR $upass == '') {

      message("Invalid Username and Password!", "error");
      redirect(web_root."index.php");
         
    } else {   
        $cus = new Customer();
        $cusres = $cus::cusAuthentication($email,$h_upass);

        if ($cusres==true){


           redirect(web_root."index.php?q=profile");
        }else{
             message("Invalid Username and Password! Please contact administrator", "error");
             redirect(web_root."index.php?q=login");
        }
 
 }
}
 
 ?> 
 <style type="text/css">
   .span6 {
    margin-left:30%;
   }
 </style>

   <!-- s-content
    ================================================== -->
    <section class="s-content s-content--narrow s-content--no-padding-bottom">
        <article class="row format-standard">

            <div class="s-content__header col-full">
                <h1 class="s-content__header-title">
                  Login
                </h1>  
            </div> <!-- end s-content__header -->
    
            <div class="s-content__media col-full">
                <div class="s-content__post-thumb">
                    <img src=""   sizes="(max-width: 2000px) 100vw, 2000px" alt="" >

                    <?php check_message();?>
                </div>
                    <form class="form-horizontal span6 " action="" method="POST">
                                <div class="form-group">
                                  <div class="col-nine">
                                    <label class="control-label" for=
                                    "U_USERNAME">Username:</label> 
                                          <input   id="U_USERNAME" name="U_USERNAME" placeholder="Username" type="text" class="col-nine" >  
                                  </div> 
                 
                                  <div class="col-nine">
                                    <label class="control-label" for=
                                    "U_PASS">Password:</label> 
                                     <input name="U_PASS" id="U_PASS" placeholder="Password" type="password" class="col-nine ">
                             
                                  </div> 
                                  </div>
                                  <div class="form-group">
                                  <div class="col-nine"> 
                                    <button type="submit" id="submit" name="submit" class="btn btn-pup btn-sm">  Login</button>  
                                  </div>
                                </div>

                                 <div class="form-group">
                                  <div class="col-nine">  <a href="passwordrecover.php">Forgot password?</a> </div>
                                </div> 
                            </form> 

                    </div> <!-- end s-content__media --> 
    <br>
    <br>
        </article> 
    </section> <!-- s-content -->