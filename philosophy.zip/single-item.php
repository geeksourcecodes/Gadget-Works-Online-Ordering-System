<style type="text/css">
.s-content__post-thumb {
    text-align: center;
}
    .s-content__post-thumb img {
        width: 50%;
        height: 150px;
    }
</style> 

   <form   method="POST" action="cart/controller.php?action=add">
 <?php 
 $PROID =   $_GET['id']; 
 $query = "SELECT * FROM `tblpromopro` pr , `tblproduct` p , `tblcategory` c
            WHERE pr.`PROID`=p.`PROID` AND  p.`CATEGID` = c.`CATEGID`  AND p.`PROID`=" . $PROID;
            $mydb->setQuery($query);
            $cur = $mydb->loadResultList();


  foreach ($cur as $result) { 
   
 ?>
    <!-- s-content
    ================================================== -->
    <section class="s-content s-content--narrow s-content--no-padding-bottom">
        <article class="row format-standard">

            <div class="s-content__header col-full">
                <h1 class="s-content__header-title">
                   <?php echo $result->PRODESC; ?>
                </h1>
                <ul class="s-content__header-meta"> 
                    <li class="cat">
                        In
                        <a href="#0"><?php echo   $result->CATEGORIES;?></a> 
                    </li>
                </ul>
            </div> <!-- end s-content__header -->
    
            <div class="s-content__media col-full">
                <div class="s-content__post-thumb">
                    <img src="<?php echo web_root . 'admin/products/'.  $result->IMAGES;?>" 
                         
                         sizes="(max-width: 2000px) 100vw, 2000px" alt="" >
                </div>
            </div> <!-- end s-content__media -->

            <div class="col-full s-content__main">

                <input type="hidden" name="PROPRICE" value="<?php  echo $result->PRODISPRICE; ?>">
                <input type="hidden" id="PROQTY" name="PROQTY" value="<?php  echo $result->PROQTY; ?>">

                <input type="hidden" name="PROID" value="<?php  echo $result->PROID; ?>">
                <!-- <h3><?php echo $result->PRONAME ; ?></h3> -->
                <p class="lead"> 
                    <ul>
                    <!-- <li>Model - <?php echo $result->PROMODEL; ?></li> -->
                    <li>Type - <?php echo $result->PRODESC; ?></li>
                    <li>Price - &#8369 <?php echo $result->PROPRICE; ?></li>
                    <?php if($result->PRODISCOUNT>0){ ?>
                    <li>Discount - <?php echo $result->PRODISCOUNT; ?> % </li> 

                    <li>Discounted Price - &#8369 <?php echo $result->PRODISPRICE; ?> </li> 
                    <?php } ?>
                    <li>Available Quantity - <?php echo $result->PROQTY; ?></li>
                </ul>

                 <button  type="submit"  class="btn btn-pup btn-sm"  name="btnorder">Order Now!</button>
                </p>

      
            </div> <!-- end s-content__main -->

        </article> 
    </section> <!-- s-content -->

 <?php } ?>

</form>   