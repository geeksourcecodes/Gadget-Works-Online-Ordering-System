  <!-- pageheader -->
    <!-- ================================================== -->
    <div class="s-pageheader">

        <header class="header">
            <div class="header__content row">

                <div class="header__logo">
                    <a class="logo" href="<?php echo web_root;?>index.php">
                        <!-- <img src="images/logo.svg" alt="Homepage"> -->
                        <label style="font-size: 30px;color: #fff">  GADGET WORKS</label>
                    </a>
                </div> <!-- end header__logo -->

                <ul class="header__social">
                   <li class="dropdown dropdown-toggle ">
                      <a  data-toggle="tooltip" data-placement="left" title="Contact Us"   href="<?php echo web_root.'index.php?q=contact';  ?>">
                       <i class="fa fa-phone fa-fw"> </i>  091256584879
                      </a>
                    </li>
                    <li class="dropdown dropdown-toggle">
                      <a   data-toggle="tooltip" data-placement="right"  title="Cart List"  href="<?php echo web_root.'index.php?q=cart';  ?>"> 
                       <i class="fa fa-shopping-cart fa-fw"> </i> <?php echo  isset($cart) ? $cart : "(0)" ; ?> 
                      </a>
                    </li>   
                </ul> <!-- end header__social -->

                <a class="header__search-trigger" href="#0"></a>

                <div class="header__search">

                     <form role="search" action="index.php?q=product" method="post" class="header__search-form" >
                        <label>
                            <span class="hide-content">Search for:</span>
                            <input type="search" class="search-field" placeholder="Type Keywords" value="" name="search" title="Search for:" autocomplete="off">
                        </label>
                        <input type="submit" class="search-submit" name="btnsearch" value="Search">
                    </form>
        
                    <a href="#0" title="Close Search" class="header__overlay-close">Close</a>

                </div>  <!-- end header__search -->


                <a class="header__toggle-menu" href="#0" title="Menu"><span>Menu</span></a>

                <nav class="header__nav-wrap">

                    <h2 class="header__nav-heading h6">Site Navigation</h2>

                    <ul class="header__nav">
                       <li class="<?php echo ($_GET['q']=='') ? "current" : false;?>"><a href="<?php echo web_root.'index.php'; ?>" title="">Home</a></li>
                     <!--    <li class="has-children">
                            <a href="#0" title="">Categories</a>
                            <ul class="sub-menu">
                            <li><a href="category.html">Lifestyle</a></li>
                            <li><a href="category.html">Health</a></li>
                            <li><a href="category.html">Family</a></li>
                            <li><a href="category.html">Management</a></li>
                            <li><a href="category.html">Travel</a></li>
                            <li><a href="category.html">Work</a></li>
                            </ul>
                        </li>   -->
                        <li class="<?php echo ($_GET['q']=='product') ? "current" : false;?>"><a href="<?php echo web_root.'index.php?q=product'; ?>" title="">Product</a></li>
                        <li class="<?php echo ($_GET['q']=='contact') ? "current" : false;?>"><a href="<?php echo web_root.'index.php?q=contact';  ?>" title="">Contact</a></li>
                    </ul> <!-- end header__nav
 -->
                    <a href="#0" title="Close Menu" class="header__overlay-close close-mobile-menu">Close</a>

                </nav> <!-- end header__nav-wrap -->

            </div> <!-- header-content -->
        </header> <!-- header -->

    </div> 