<!DOCTYPE html>
<html class="no-js" lang="en">
<head>

    <!--- basic page needs
    ================================================== -->
    <meta charset="utf-8">
    <title>Gadgets Works</title>
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- mobile specific metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- CSS
    ================================================== -->
    <link href="<?php echo web_root; ?>css/ekko-lightbox.css" rel="stylesheet">
     <link href="<?php echo web_root; ?>css/dataTables.bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo web_root; ?>css/base.css">
    <link rel="stylesheet" href="<?php echo web_root; ?>css/vendor.css">
    <link rel="stylesheet" href="<?php echo web_root; ?>css/main.css">
    <!-- <link rel="stylesheet" href="<?php echo web_root; ?>css/costum.css"> -->

    <!-- script
    ================================================== -->
    <script src="<?php echo web_root; ?>js/modernizr.js"></script>
    <script src="<?php echo web_root; ?>js/pace.min.js"></script>

    <!-- favicons
    ================================================== -->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">

</head>

<body id="top" onload="totalprice()">

    <!-- pageheader
    ================================================== -->
<div style="text-align: right;margin-bottom: 30px;">
   <ul class="header__nav navbar-fixed-top" style="background-color: #181818;" >
            <?php if (isset($_SESSION['CUSID']) ){  

$mydb->setQuery("SELECT count(*) as 'num',SUMMARYID FROM  `tblsummary` 
      WHERE     `CUSTOMERID`='".$_SESSION['CUSID']."'  AND 
      ORDEREDSTATS in ('Confirmed','Cancelled') AND HVIEW=0");    
$res = $mydb->loadResultList();

    foreach ($res as $key) { 
    $_SESSION['gcNotify'] = $key->num; 
  }
?>
     

            <li class="has-children dropdown  dropdown-toggle">
               <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                  <i class="fa fa-user fa-fw"></i>
                    <?php echo $_SESSION['CUSNAME']; ?>
                  <i class="caret"> </i> 
               </a>

                  <ul class="dropdown-menu dropdown-acnt"> 
                    <li><a title="Edit" href="<?php echo web_root; ?>index.php?q=profile"  >My Profile</a></li> 
                    <li> <a  href="logout.php">Logout</a></li>  
                  </ul> 
            </li>  
 
<?php  }else{ ?>
    <li><a href="<?php echo web_root; ?>index.php?q=login"><i class="fa fa-lock"></i> Login</a></li>
<?php } ?>
 </ul>  
</div>


 <?php 
 
if (isset($_SESSION['gcCart'])){
  if (@count($_SESSION['gcCart'])>0) {
    $cart = '<span class="carttxtactive">('.@count($_SESSION['gcCart']) .')</span>';
  } 
 
}  


  if (!isset($_GET['q'])) {
    # code...
     require_once ('mainheader.php');
  }else{
     require_once ('pageheader.php');
  }
 ?>

    

<!-- content ================================ -->

      <?php

      if($title=='Profile' or $title=='Track Order' ){ 

      require_once $content; 

      }else{
      require_once $content;  
      }

      ?>

         <!-- s-extra
    ================================================== -->
    <section class="s-extra">

        <div class="row top">

            <div class="col-eight md-six tab-full popular">
                <h3>Popular Posts</h3>



                <div class="block-1-2 block-m-full popular__posts">
 <?php 


       
          $query = "SELECT * FROM `tblpromopro` pr , `tblproduct` p , `tblcategory` c
                    WHERE pr.`PROID`=p.`PROID` AND  p.`CATEGID` = c.`CATEGID`  AND PROQTY>0  LIMIT 6  ";
      


          $mydb->setQuery($query);
          $cur = $mydb->loadResultList();
         
          foreach ($cur as $result) { 
  
   ?> 
                    <article class="col-block popular__post">
                        <a href="<?php  echo web_root; ?>index.php?q=single-item&id=<?php echo $result->PROID; ?>" class="popular__thumb">
                            <img src="<?php  echo web_root.'admin/products/'. $result->IMAGES; ?>" alt="">
                        </a>
                        <h5><a href="#0"><?php  echo    $result->PRODESC; ?></a></h5>
                        <section class="popular__meta">
                                <span class="popular__author"><span>  Price  &#8369 <?php  echo $result->PRODISPRICE; ?></span></span>
                            <span class="popular__date"><span>Available Quantity: <?php  echo $result->PROQTY; ?></span></span>
                        </section>
                    </article>
                     
        <?php } ?>
                </div> <!-- end popular_posts -->
            </div> <!-- end popular -->
            
            <div class="col-four md-six tab-full about">
                <h3>About Philosophy</h3>

                <p>
                Donec sollicitudin molestie malesuada. Nulla quis lorem ut libero malesuada feugiat. Pellentesque in ipsum id orci porta dapibus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Donec sollicitudin molestie malesuada.
                </p>

                <ul class="about__social">
                    <li>
                        <a href="#0"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    </li>
                    <li>
                        <a href="#0"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                    </li>
                    <li>
                        <a href="#0"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                    </li>
                    <li>
                        <a href="#0"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                    </li>
                </ul> <!-- end header__social -->
            </div> <!-- end about -->

        </div> <!-- end row -->

        <div class="row bottom tags-wrap">
            <div class="col-full tags">
                <h3>Categories</h3>

                <div class="tagcloud">
                    <?php 
                    $query = "SELECT * FROM `tblcategory`  ";
      


          $mydb->setQuery($query);
          $cur = $mydb->loadResultList();
         
          foreach ($cur as $result) { 


                    ?>
                    <a href="#0"><?php echo $result->CATEGORIES;?></a> 
                <?php } ?>
                </div> <!-- end tagcloud -->
            </div> <!-- end tags -->
        </div> <!-- end tags-wrap -->

    </section> <!-- end s-extra -->


    <!-- s-footer
    ================================================== -->
    <footer class="s-footer">

        <div class="s-footer__main">
            <div class="row">
                
                <div class="col-two md-six mob-full s-footer__sitelinks">
                        
                    <h4>Quick Links</h4>

                    <ul class="s-footer__linklist">
                        <li class="<?php echo ($_GET['q']=='') ? "current" : false;?>"><a href="<?php echo web_root.'index.php'; ?>" title="">Home</a></li>
                       <!--  <li class="has-children">
                            <a href="#0" title="">Categories</a>
                            <ul class="sub-menu">
                            <li><a href="category.html">Lifestyle</a></li>
                            <li><a href="category.html">Health</a></li>
                            <li><a href="category.html">Family</a></li>
                            <li><a href="category.html">Management</a></li>
                            <li><a href="category.html">Travel</a></li>
                            <li><a href="category.html">Work</a></li>
                            </ul>
                        </li> -->  
                        <li class="<?php echo ($_GET['q']=='product') ? "current" : false;?>"><a href="<?php echo web_root.'index.php?q=product'; ?>" title="">Product</a></li>
                        <li class="<?php echo ($_GET['q']=='contact') ? "current" : false;?>"><a href="<?php echo web_root.'index.php?q=contact';  ?>" title="">Contact</a></li>
                    </ul>

                </div> <!-- end s-footer__sitelinks --> 
                <div class="col-two md-six mob-full s-footer__social">
                        
                    <h4>Social</h4>

                    <ul class="s-footer__linklist">
                        <li><a href="#0">Facebook</a></li>
                        <li><a href="#0">Instagram</a></li>
                        <li><a href="#0">Twitter</a></li>
                        <li><a href="#0">Pinterest</a></li>
                        <li><a href="#0">Google+</a></li>
                        <li><a href="#0">LinkedIn</a></li>
                    </ul>

                </div> <!-- end s-footer__social -->

                <div class="col-five md-full end s-footer__subscribe">
                        
                    <h4>Our Newsletter</h4>

                    <p>Sit vel delectus amet officiis repudiandae est voluptatem. Tempora maxime provident nisi et fuga et enim exercitationem ipsam. Culpa consequatur occaecati.</p>

                    <div class="subscribe-form">
                        <form id="mc-form" class="group" novalidate="true">

                            <input type="email" value="" name="EMAIL" class="email" id="mc-email" placeholder="Email Address" required="">
                
                            <input type="submit" name="subscribe" value="Send">
                
                            <label for="mc-email" class="subscribe-message"></label>
                
                        </form>
                    </div>

                </div> <!-- end s-footer__subscribe -->

            </div>
        </div> <!-- end s-footer__main -->

        <div class="s-footer__bottom">
            <div class="row">
                <div class="col-full">
                    <div class="s-footer__copyright">
                        <span>© Copyright Philosophy 2018</span> 
                        <span>Site Template by <a href="https://colorlib.com/">Colorlib</a></span>
                    </div>

                    <div class="go-top">
                        <a class="smoothscroll" title="Back to Top" href="#top"></a>
                    </div>
                </div>
            </div>
        </div> <!-- end s-footer__bottom -->

    </footer> <!-- end s-footer -->

 <div class="modal fade" id="myOrdered">
 </div>
    <!-- preloader
    ================================================== -->
    <div id="preloader">
        <div id="loader">
            <div class="line-scale">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div>


    <!-- Java Script
    ================================================== -->
     <!-- jQuery -->
    <script src="<?php echo web_root; ?>jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo web_root; ?>js/bootstrap.min.js"></script>
    <script src="<?php echo web_root; ?>js/jquery-3.2.1.min.js"></script>
    <script src="<?php echo web_root; ?>js/plugins.js"></script>
    <script src="<?php echo web_root; ?>js/main.js"></script>
    <script type="text/javascript" language="javascript" src="<?php echo web_root; ?>js/janobe.js"></script> 
    <script type="text/javascript" language="javascript" src="<?php echo web_root; ?>js/ekko-lightbox.js"></script> 
     <script src="<?php echo web_root; ?>js/jquery.dataTables.min.js"></script>
    <script src="<?php echo web_root; ?>js/dataTables.bootstrap.min.js"></script>
     <script type="text/javascript">
  $(document).on("click", ".proid", function () {
    // var id = $(this).attr('id');
      var proid = $(this).data('id')
    // alert(proid)
       $(".modal-body #proid").val( proid )

      });

</script>
 <script>
    // tooltip demo
    $('.tooltip-demo').tooltip({
        selector: "[data-toggle=tooltip]",
        container: "body"
    })

    // popover demo
    $("[data-toggle=popover]")
        .popover()
    </script>


      <script>
        $('.carousel').carousel({
            interval: 5000 //changes the speed
        })
    </script>


</body>

</html>