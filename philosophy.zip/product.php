  <style type="text/css">
    
    .entry__thumb img {
      width: 100%;
    }
  </style>

  <!-- s-content
    ================================================== -->
    <section class="s-content">

        <div class="row narrow">
            <div class="col-full s-content__header" data-aos="fade-up">
                <h1>Product</h1>

                <p class="lead">Dolor similique vitae. Exercitationem quidem occaecati iusto. Id non vitae enim quas error dolor maiores ut. Exercitationem earum ut repudiandae optio veritatis animi nulla qui dolores.</p>
            </div>
        </div>
        
        <div class="row masonry-wrap">
            <div class="masonry">

                <div class="grid-sizer"></div>

  <?php 


        if(isset($_POST['btnsearch'])) {
          $query = "SELECT * FROM `tblpromopro` pr , `tblproduct` p , `tblcategory` c
                    WHERE pr.`PROID`=p.`PROID` AND  p.`CATEGID` = c.`CATEGID`  AND PROQTY>0 
          AND ( `CATEGORIES` LIKE '%{$_POST['search']}%' OR `PRODESC` LIKE '%{$_POST['search']}%' or `PROQTY` LIKE '%{$_POST['search']}%' or `PROPRICE` LIKE '%{$_POST['search']}%')";
        }elseif(isset($_GET['category'])){
          $query = "SELECT * FROM `tblpromopro` pr , `tblproduct` p , `tblcategory` c
                    WHERE pr.`PROID`=p.`PROID` AND  p.`CATEGID` = c.`CATEGID`  AND PROQTY>0 AND CATEGORIES='{$_GET['category']}'";
        }else{
          $query = "SELECT * FROM `tblpromopro` pr , `tblproduct` p , `tblcategory` c
                    WHERE pr.`PROID`=p.`PROID` AND  p.`CATEGID` = c.`CATEGID`  AND PROQTY>0 ";
        }


          $mydb->setQuery($query);
          $cur = $mydb->loadResultList();
         
          foreach ($cur as $result) { 
  
   ?> 

       <form   method="POST" action="cart/controller.php?action=add">
                <article class="masonry__brick entry format-standard" data-aos="fade-up">
                        
                    <div class="entry__thumb">
                        <a href="<?php  echo web_root; ?>index.php?q=single-item&id=<?php echo $result->PROID; ?>" class="entry__thumb-link">
                            <img src="<?php  echo web_root.'admin/products/'. $result->IMAGES; ?>" 
                                alt="">
                        </a>
                    </div>
 
                    <div class="entry__text">
                        <div class="entry__header"> 
                            <h1 class="entry__title"><a href="<?php  echo web_root; ?>index.php?q=single-item&id=<?php echo $result->PROID; ?>"><?php  echo    $result->PRODESC; ?></a></h1>
                            
                        </div>
                        <div class="entry__excerpt">
                            <p>
                              <input type="hidden" name="PROPRICE" value="<?php  echo $result->PROPRICE; ?>">
                              <input type="hidden" id="PROQTY" name="PROQTY" value="<?php  echo $result->PROQTY; ?>">

                              <input type="hidden" name="PROID" value="<?php  echo $result->PROID; ?>">
                               Price  &#8369 <?php  echo $result->PRODISPRICE; ?><br/>
                               Available Quantity: <?php  echo $result->PROQTY; ?><br/>
                            </p>
                             <div class="form-group">
                              <div class="row">
                                <div class="col-xs-12 col-sm-12">
                                  <button  type="submit"  class="btn btn-pup btn-sm"  name="btnorder">Order Now!</button>
                                </div>
                              </div>
                            </div>
                        </div>
                        <div class="entry__meta">
                            <span class="entry__meta-links">
                                <a href="category.html"><?php  echo $result->CATEGORIES; ?></a>  
                            </span>
                        </div>
                    </div>
    
                </article> <!-- end article -->
            </form>
    <?php } ?>           

            </div> <!-- end masonry -->
        </div> <!-- end masonry-wrap -->
<!-- 
        <div class="row">
            <div class="col-full">
                <nav class="pgn">
                    <ul>
                        <li><a class="pgn__prev" href="#0">Prev</a></li>
                        <li><a class="pgn__num" href="#0">1</a></li>
                        <li><span class="pgn__num current">2</span></li>
                        <li><a class="pgn__num" href="#0">3</a></li>
                        <li><a class="pgn__num" href="#0">4</a></li>
                        <li><a class="pgn__num" href="#0">5</a></li>
                        <li><span class="pgn__num dots">…</span></li>
                        <li><a class="pgn__num" href="#0">8</a></li>
                        <li><a class="pgn__next" href="#0">Next</a></li>
                    </ul>
                </nav>
            </div>
        </div> -->

    </section> <!-- s-content -->